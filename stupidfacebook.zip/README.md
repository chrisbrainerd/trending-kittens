# trending-kittens
Kittens Are Always Trending - a Chrome extension
================================
This is a chrome extension written to replace the Trending Stories section of your Facebook main page with gifs of your choosing. 

Todos:
------
* sanitize inputs
* test with other facebook users (Facebook does tons of A/B testing and changes their main page without any fanfare - no idea if / how often this would end up being depreciated as a result)

